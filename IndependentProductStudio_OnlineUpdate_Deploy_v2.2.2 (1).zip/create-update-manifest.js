const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

async function main() {
  const archive = process.argv[2];
  if (!archive) {
    throw new Error('用法：node scripts/create-update-manifest.js <新版ZIP路径> [下载地址] [更新说明]');
  }
  const absolute = path.resolve(archive);
  const stat = await fs.promises.stat(absolute);
  if (!stat.isFile()) throw new Error('指定的更新 ZIP 不存在');
  const packageInfo = require('../package.json');
  const hash = crypto.createHash('sha256');
  await new Promise((resolve, reject) => {
    const stream = fs.createReadStream(absolute);
    stream.on('data', chunk => hash.update(chunk));
    stream.once('error', reject);
    stream.once('end', resolve);
  });
  const outputDir = path.resolve(__dirname, '..', 'update-server');
  await fs.promises.mkdir(outputDir, { recursive: true });
  const manifest = {
    version: packageInfo.version,
    download_url: process.argv[3] || path.basename(absolute),
    sha256: hash.digest('hex'),
    size_bytes: stat.size,
    notes: process.argv[4] || `独立商品图工坊 ${packageInfo.version} 更新`,
    mandatory: false
  };
  const output = path.join(outputDir, 'version.json');
  await fs.promises.writeFile(output, `${JSON.stringify(manifest, null, 2)}\n`, 'utf8');
  process.stdout.write(`已生成 ${output}\nSHA-256: ${manifest.sha256}\n大小: ${manifest.size_bytes} bytes\n`);
}

main().catch(error => {
  process.stderr.write(`${error.message}\n`);
  process.exitCode = 1;
});
